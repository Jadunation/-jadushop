from django.apps import AppConfig

class AdminAppConfig(AppConfig):
    name = 'admin_app'

    def ready(self):
        import admin_app.signals  # Ensure signals are loaded